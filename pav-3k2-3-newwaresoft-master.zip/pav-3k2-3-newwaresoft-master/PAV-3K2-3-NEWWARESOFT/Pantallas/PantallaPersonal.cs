﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAV_3K2_3_NEWWARESOFT.Pantallas
{
    public partial class PantallaPersonal : Form
    {
        public PantallaPersonal()
        {
            InitializeComponent();
        }
    }
}
