﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAV_3K2_3_NEWWARESOFT.Modelos
{
    public class Cliente
    {
        private int id { get; set; }
        private string apellido { get; set; }
        private string nombres { get; set; }
        private int telefono { get; set; }
        private string calle { get; set; }
        private int nroCalle { get; set; }
        private string eMail {get;set;}

        public Cliente()
        {


        }


}
}
