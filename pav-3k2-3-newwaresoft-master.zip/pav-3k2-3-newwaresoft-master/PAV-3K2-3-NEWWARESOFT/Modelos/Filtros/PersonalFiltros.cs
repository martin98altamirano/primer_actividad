﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAV_3K2_3_NEWWARESOFT.Modelos.Filtros
{
    public class PersonalFiltros
    {
        public DateTime? FechaIngresoDesde { get; set; }
        public DateTime? FechaIngresoHasta { get; set; }
        public DateTime? FechaEgresoDesde { get; set; }
        public DateTime? FechaEgresoHasta { get; set; }
    }
}
